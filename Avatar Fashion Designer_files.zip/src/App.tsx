import  { useState } from 'react';
import { Camera, Upload, Zap, Star, Users, Settings, Globe, Image, Play } from 'lucide-react';

function App() {
  const [selectedPlatform, setSelectedPlatform] = useState('VRChat');
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);

  const platforms = ['VRChat', 'Roblox', 'Fortnite', 'Zepeto', 'Horizon Worlds'];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImages(prev => [...prev, e.target?.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const generateAvatarStyle = async () => {
    const response = await fetch('https://hooks.jdoodle.net/proxy?url=https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [{
          role: 'user',
          content: `Generate a detailed avatar outfit description for ${selectedPlatform} based on uploaded fashion images. Include colors, style elements, and platform-specific customization tips.`
        }],
        max_tokens: 200
      })
    });
    const data = await response.json();
    alert(data.choices[0].message.content);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <nav className="px-6 py-4 bg-black/20 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Zap className="w-8 h-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">StyleSync</span>
          </div>
          <div className="flex items-center space-x-6">
            <a href="#" className="text-gray-300 hover:text-white">Features</a>
            <a href="#" className="text-gray-300 hover:text-white">Platforms</a>
            <button className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">
              Sign In
            </button>
          </div>
        </div>
      </nav>

      <div className="px-6 py-16">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-white mb-6">
              AI Fashion Curator for Digital Worlds
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Transform your real-world style into stunning digital avatar outfits for VRChat, Roblox, Fortnite, and more
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl font-bold text-white mb-6">Upload Your Style</h2>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="border-2 border-dashed border-gray-400 rounded-lg p-8 text-center">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                  />
                  <label htmlFor="image-upload" className="cursor-pointer">
                    <Camera className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-300 mb-2">Upload photos of your wardrobe</p>
                    <p className="text-sm text-gray-500">PNG, JPG up to 10MB each</p>
                  </label>
                </div>
                
                {uploadedImages.length > 0 && (
                  <div className="grid grid-cols-3 gap-2 mt-4">
                    {uploadedImages.map((img, idx) => (
                      <img key={idx} src={img} className="w-full h-20 object-cover rounded" />
                    ))}
                  </div>
                )}

                <div className="mt-6">
                  <label className="block text-white mb-2">Target Platform</label>
                  <select
                    value={selectedPlatform}
                    onChange={(e) => setSelectedPlatform(e.target.value)}
                    className="w-full bg-black/30 text-white rounded-lg p-3 border border-white/20"
                  >
                    {platforms.map(platform => (
                      <option key={platform} value={platform}>{platform}</option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={generateAvatarStyle}
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-lg mt-6 hover:from-purple-700 hover:to-blue-700 flex items-center justify-center space-x-2"
                >
                  <Zap className="w-5 h-5" />
                  <span>Generate Avatar Style</span>
                </button>
              </div>
            </div>

            <div className="space-y-6">
              <img
                src="https://images.unsplash.com/photo-1601401031947-9cdea53e4886?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwYXZhdGFyJTIwbWV0YXZlcnNlJTIwZGlnaXRhbCUyMGNsb3RoaW5nJTIwdmlydHVhbCUyMHJlYWxpdHl8ZW58MHx8fHwxNzUxMTI2MTUxfDA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800"
                alt="Digital fashion avatar"
                className="w-full rounded-2xl"
              />
              <div className="grid grid-cols-2 gap-4">
                <img
                  src="https://images.unsplash.com/photo-1683967195780-55103697c03c?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxmYXNoaW9uJTIwYXZhdGFyJTIwbWV0YXZlcnNlJTIwZGlnaXRhbCUyMGNsb3RoaW5nJTIwdmlydHVhbCUyMHJlYWxpdHl8ZW58MHx8fHwxNzUxMTI2MTUxfDA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800"
                  alt="Virtual reality fashion"
                  className="w-full rounded-lg"
                />
                <img
                  src="https://images.unsplash.com/photo-1622023884736-cb8c0de84f6e?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHw1fHxmYXNoaW9uJTIwYXZhdGFyJTIwbWV0YXZlcnNlJTIwZGlnaXRhbCUyMGNsb3RoaW5nJTIwdmlydHVhbCUyMHJlYWxpdHl8ZW58MHx8fHwxNzUxMTI2MTUxfDA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800"
                  alt="Digital style avatar"
                  className="w-full rounded-lg"
                />
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
              <Image className="w-8 h-8 text-purple-400 mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Style Analysis</h3>
              <p className="text-gray-300">AI analyzes your wardrobe photos to understand your personal style preferences</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
              <Globe className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Multi-Platform</h3>
              <p className="text-gray-300">Generate outfits optimized for VRChat, Roblox, Fortnite, and other metaverse platforms</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
              <Star className="w-8 h-8 text-yellow-400 mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Perfect Match</h3>
              <p className="text-gray-300">Get detailed customization guides to recreate your style in digital worlds</p>
            </div>
          </div>

          <div className="text-center">
            <h2 className="text-3xl font-bold text-white mb-8">Supported Platforms</h2>
            <div className="flex flex-wrap justify-center gap-4">
              {platforms.map(platform => (
                <div key={platform} className="bg-white/10 backdrop-blur-sm rounded-lg px-6 py-3 border border-white/20">
                  <span className="text-white font-medium">{platform}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
 